CREATE TABLE `icheck`.`kids` (
  `kid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(10) NOT NULL,
  `clas` VARCHAR(10) NOT NULL,
  `upload` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kid`));